#!/usr/bin/env python

from common import PipelineComponent

