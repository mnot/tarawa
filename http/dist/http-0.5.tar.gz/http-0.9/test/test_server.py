#!/usr/bin/env python

import sys, os, os.path
sys.path.append(os.path.join(os.getcwd(), "../lib"))

from server.api.Resource import Resource
from server.adapters.CGI import CGI

class Test(Resource):
    
    def GET(self, request, response):
        response.body = "foo"
    
server = CGI(Test, '')
server.serve()