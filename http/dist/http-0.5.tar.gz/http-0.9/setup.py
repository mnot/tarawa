#!/usr/bin/env python

from distutils.core import setup

setup(name='http',
		version = '0.9',
		package_dir = {'http': 'lib'},
		packages = ['http', 'http.header', 'http.feature', 
					'http.client', 'http.client.adapter', 'http.client.api',
					'http.server', 'http.server.adapter', 'http.server.api',
				   ],
		author = 'Mark Nottingham',
		author_email = 'mnot@pobox.com',
		url = '',
		description = 'HTTP APIs',
		license = 'MIT',
		classifiers = [
		  'License :: OSI Approved :: MIT License',
		  'Operating System :: OS Independent',
		  'Programming Language :: Python',
		  'Topic :: Software Development :: Libraries :: Python Modules',
		],
	)
